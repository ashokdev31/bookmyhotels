<?php 
	include_once('../../../wp-load.php');

	if( function_exists('gdlr_hotel_ical_routine') ){
		gdlr_hotel_ical_routine();
	}

